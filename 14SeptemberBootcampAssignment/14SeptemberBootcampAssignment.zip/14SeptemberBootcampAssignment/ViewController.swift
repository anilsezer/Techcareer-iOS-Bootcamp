//
//  ViewController.swift
//  14SeptemberBootcampAssignment
//
//  Created by Anıl Sezer on 16.09.2023.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let overlayView = UIView(frame: backgroundImage.bounds)
        overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        backgroundImage.addSubview(overlayView)
        
        
    }
    
}

