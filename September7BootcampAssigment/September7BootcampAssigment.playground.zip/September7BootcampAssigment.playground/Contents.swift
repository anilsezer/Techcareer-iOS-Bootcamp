import UIKit

// Calculation of Sum of Interior Angles
class NumberOfSides {
    
    func sumOfInteriorAngles(numberOfSides: Int?) -> Int {
        
        let total = (numberOfSides! - 2) * 180
        print("Sum of Interior Angles = \(total)°")
        return total
    }
}
let sides = NumberOfSides()
sides.sumOfInteriorAngles(numberOfSides: 10)

//Overtime Wage Calculation
class SalaryCounter {
    
    func calculatePrice(workDays: Int?) -> Int {
        
        let workingHours = workDays! * 8
        let hourlyWage = 10
        let overtimeWage = 20
        var calculatedPrice = workingHours * hourlyWage
        
        if workingHours > 160 {
            let regularHours = 160
            let overtimeHours = workingHours - regularHours
            calculatedPrice = (regularHours * hourlyWage) + (overtimeHours * overtimeWage)
        } else {
            calculatedPrice = workingHours * hourlyWage
        }
        
        print("You earned : \(calculatedPrice)₺")
        return calculatedPrice
    }
}

let totalEarnings = SalaryCounter()
totalEarnings.calculatePrice(workDays: 21)

// Calculate Quota
class CalculateQuota {
    
    func calculateQuotaCost(quotaAmount: Int) -> Int {
        
        let quotaPrice = 2
        let excessPrice = 4
        var totalCost = quotaAmount * quotaPrice
        
        if quotaAmount <= 50 {
            //Returns totalCost
        } else {
            let normalQuota = 50
            let excessQuotaAmount = quotaAmount - normalQuota
            totalCost = (normalQuota * quotaPrice) + (excessQuotaAmount * excessPrice)
        }
        print("Total Bill = \(totalCost)₺")
        return totalCost
    }
}

let calculator = CalculateQuota()
calculator.calculateQuotaCost(quotaAmount: 51)

// Fahrenheit Conversion
class FahrenheitConverter {
    
    func calculateFahrenheit(celsiusDegrees: Double) -> Double {
        
        let fahrenheit = (celsiusDegrees * 1.8) + 32
        
        print("Fahrenheit = \(fahrenheit)")
        return fahrenheit
        
    }
}

let converter = FahrenheitConverter()
converter.calculateFahrenheit(celsiusDegrees: 32)


// Calculate Rectangle Perimeter
class RectanglePerimeterCalculator {
    
    func calculateArea(shortSide: Int, longSide: Int) -> Int {
        
        let area = shortSide * longSide
        print("Perimeter of Rectangle = \(area)")
        return area
    }
    
}

let rectangleCalculator = RectanglePerimeterCalculator()
rectangleCalculator.calculateArea(shortSide: 10, longSide: 20)

// Calculate Factorial
class FactorialCalculator {
    
    func calculateFactorial(n: Int) -> Int {
        
        var result = 1
        
        for i in 1...n {
            result *= i
        }
        print("\(n) is equal to \(result) factorial")
        return result
    }
}

let factorial = FactorialCalculator()
factorial.calculateFactorial(n: 5)


// Count the Letter "a"
class LetterCounter {
    
    func countA(name: String) -> Int {
        var aCount = 0
        for letter in name {
            if letter == "a" || letter == "A" {
                aCount += 1
            }
        }
        print("The are \(aCount) letters a in the word")
        return aCount
    }
}

let counter = LetterCounter()
counter.countA(name: "Ahmet")
